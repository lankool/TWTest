package com.example.tw_testazlan;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    ArrayList<String> firstNames;
    ArrayList<String> lastNames;

    public CustomAdapter(ArrayList<String> firstNames, ArrayList<String> lastNames, MainActivity mainActivity) {
        this.firstNames = firstNames;
        this.lastNames = lastNames;
    }

    @NonNull
    @Override
    public  MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rowlayout, parent, false);
        MyViewHolder vh = new MyViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.firstnames.setText(firstNames.get(position));
        holder.lastnames.setText(lastNames.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Toast.makeText(firstNames.get(position), Toast.LENGTH_SHORT).show();
            }
        });



    }

    @Override
    public int getItemCount() {
        return firstNames.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView firstnames, lastnames;

        public MyViewHolder(@NonNull View itemView) {

            super(itemView);

            firstnames = itemView.findViewById(R.id.firstnames);
        }

    }
}
